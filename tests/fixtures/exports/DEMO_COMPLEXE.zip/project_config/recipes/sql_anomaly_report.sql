-- Synthetic SQL recipe (fixture).
SELECT a.depot_id,
       d.depot_name,
       COUNT(*) AS anomalies,
       MAX(a.event_ts) AS last_anomaly_ts
FROM ${projectKey}_anomalies_clean a
LEFT JOIN ${projectKey}_depots_clean d ON a.depot_id = d.depot_id
WHERE a.event_ts >= '${start_date}'
GROUP BY a.depot_id, d.depot_name
